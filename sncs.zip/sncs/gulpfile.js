const gulp = require('gulp');
const connect = require('gulp-connect');
const sass = require('gulp-sass');
const sourcemaps = require('gulp-sourcemaps');
const concat = require('gulp-concat');
const uglify = require('gulp-uglify');
const rename = require('gulp-rename');
const babel = require('gulp-babel');
const cleanCss = require('gulp-clean-css');
// 拷贝html
gulp.task("copyHtml", function() {
    gulp.src("*.html").pipe(gulp.dest("dist"))
    gulp.src("html/*.html").pipe(gulp.dest("dist/html"))
});
// 拷贝img
gulp.task("copyImg", function() {
    gulp.src("img/**").pipe(gulp.dest("dist/img"))
});
// 拷贝图标
gulp.task("copyFonts", function() {
    gulp.src("fonts/**").pipe(gulp.dest("dist/fonts"));
});
// 拷贝数据
gulp.task("copyData", function() {
    gulp.src("json/*.json").pipe(gulp.dest("dist/json"));
});
//css/sass/scss样式文件操作
gulp.task("sass", function() {
    gulp.src("sass/*.scss")
        .pipe(sourcemaps.init())
        .pipe(sass({ outputStyle: "compressed" }))
        .pipe(sourcemaps.write())
        .pipe(gulp.dest("dist/css"))
});
// 压缩css文件
gulp.task("cleanCss", function() {
        gulp.src(["css/index.css", "css/bootstrap.min.css", "css/reset.css"])
            .pipe(cleanCss())
            .pipe(gulp.dest("dist/css"))
    })
    // es6转es5
gulp.task("babel", function() {
        gulp.src("js/*.js")
            .pipe(babel({ "presets": ["es2015"] }))
            .pipe(gulp.dest("dist/js"))
            .pipe(uglify())
            .pipe(rename({ suffix: ".min" }))
            .pipe(gulp.dest("dist/js"))
    })
    // 搭建服务器
gulp.task("server", function() {
    connect.server({ root: "dist", livereload: true })
});
// 多个执行
gulp.task("build", ["copyHtml", "copyImg", "copyData", "copyFonts"]);
//默认事件
gulp.task("default", ["build", "server", "watch"])
    // 监听改变
gulp.task("watch", function() {
    gulp.watch(["*.html", "html/*.html", "img/**", "json/*.json", "css/index.css", "sass/*.scss", "js/*.js"], ["copyHtml", "copyImg", "copyData", "cleanCss", "sass", "babel"])
})