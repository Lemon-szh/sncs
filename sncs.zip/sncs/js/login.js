$(function() {
    $(".logintab").find("a").mouseover(function() {
        $(this).addClass("yanse").siblings().removeClass("yanse");
        $(this).find("i").addClass("ii").end().siblings().find("i").removeClass("ii");
        var index = $(this).index();
        $(".tabpane").eq(index).show().siblings().hide()
    })
    $(".duanxindenglu").on("click", function() {
        $(".userlogin").hide()
        $(".phonelogin").show()
    })
    $(".zhanghaodenglu").on("click", function() {
        $(".phonelogin").hide()
        $(".userlogin").show()
    })
    $(".denglu").click(function() {
        let $username = $("#username").val()
        let $password = $("#password").val()
        if ($username && $password) {
            $.ajax({
                type: "get",
                url: "http://localhost:3000/user/" + $username,
                success: function(data) {
                    console.log(data.password);
                    console.log($password);
                    if ($password === data.password) {
                        $.cookie("username", $username, { expires: 7, path: '/' });
                        location.href = "../index.html"
                    } else {
                        alert("账户或密码错误")
                    }
                },
                error: function(data) {
                    alert("该账户不存在！")
                }
            });
        } else {
            alert("用户名密码不能为空！")
        }

    })
})