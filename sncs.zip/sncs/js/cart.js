$(function() {
    if ($.cookie('username')) {
        let username = $.cookie('username')
        let str = `<a href="javascript:;" class="login">${username}</a>
        <a href="javascript:;" class="zhuce" id="tuichu">退出</a>`
        $("#zhuangtai").html(str)
        $("#qingdenglu").hide()
        $("#userNickname").text(username)
        $("#tuichu").click(function() {
            $.cookie('username', null)
        })
        $.ajax({
            type: 'get',
            url: 'http://localhost:3000/proList/' + username,
            success: data => {
                let num = 0
                if (data.data) {
                    let Data = JSON.parse(data.data)
                    for (let key in Data) {
                        num++
                    }
                }
                $("#cartnum").text(num)
            }
        })
        let proData = null
        $.get("../json/proList.json", function(data) {
            proData = data
        })
        let html = ""
        $.get("http://localhost:3000/proList/" + username,
            function(data) {
                let str = data.data
                let Data = JSON.parse(str)
                for (let key in Data) {
                    html += `
                    <div class="list" data-id=${key}>
                        <input class="dianquanxuan3 checked" type="checkbox"/>
                        <div class="tditem">
                            <div>
                                <a href="javascript:;"><img src="../${proData[key].imgsrc}" alt=""></a>
                                <a href="javascript:;"><img src="../${proData[key].imgsrc}" alt=""></a>
                            </div>
                            <div><a href="javascript:;">${proData[key].title}</a></div>
                        </div>
                        <div class="tdspecs">${proData[key].title}</div>
                        <div class="tdprice">
                            <p>￥<span class="aprice">${proData[key].price}</span></p>
                            <p>大会据</p>
                        </div>
                        <div class="tdamount">
                            <div class="itemamount">
                                <a href="javascript:void(0);" class="btn_l">-</a>
                                <input type="text" class="text-amount" value="${Data[key]}">
                                <a href="javascript:void(0);" class="btn_r">+</a>
                            </div>
                        </div>
                        <div class="tdsum">￥<span class="zongjia">${proData[key].price*Data[key]}</span></div>
                        <div class="tdop">
                            <a href="javascript:void(0);" class="remove">移除关注</a>
                            <a href="javascript:void(0);" class="delete">删除</a>
                        </div>
                    </div>
                    `
                }
                $(".splist2").html(html)
            }
        ).then(function() {
            // 全选
            $("#checkAll").click(function() {
                $(".checked").prop("checked", $(this).prop("checked"));
                $("#checkAll1").prop("checked", $(this).prop("checked"));
                $(".dsj").text($(".checked:checked").length)
                let sum = zongprice();
                $(".mathprice").text(sum)
            })
            $("#checkAll1").click(function() {
                $(".checked").prop("checked", $(this).prop("checked"));
                $("#checkAll").prop("checked", $(this).prop("checked"));
                $(".dsj").text($(".checked:checked").length)
                let sum = zongprice();
                $(".mathprice").text(sum)
            })
            $(".checked").click(function() {
                if ($(".checked:checked").length === $(".checked").length) {
                    $("#checkAll").prop("checked", true);
                    $("#checkAll1").prop("checked", true);
                } else {
                    $("#checkAll").prop("checked", false);
                    $("#checkAll1").prop("checked", false);
                }
                $(".dsj").text($(".checked:checked").length)
                let sum = zongprice();
                $(".mathprice").text(sum)
            });
            // 总价函数
            function zongprice() {
                let num = 0
                for (let i = 0; i < $(".checked:checked").length; i++) {
                    num += parseFloat($(".checked:checked").eq(i).siblings(".tdsum").find(".zongjia").text())
                }
                return num
            }
            // 加减点击
            $(".btn_l").click(function() {
                let wrap = $(this).parents(".list")
                let price = wrap.find(".aprice").text()
                let zongjia = wrap.find(".zongjia")
                let id = wrap.attr("data-id")
                let num = $(this).siblings(".text-amount").val()
                num--
                if (num <= 1) {
                    num = 1
                }
                $(this).siblings(".text-amount").val(num)
                zongjia.text(price * num)
                $.change(username, id, num)
            })
            $(".btn_r").click(function() {
                let wrap = $(this).parents(".list")
                let price = wrap.find(".aprice").text()
                let zongjia = wrap.find(".zongjia")
                let id = wrap.attr("data-id")
                let num = $(this).siblings(".text-amount").val()
                num++
                $(this).siblings(".text-amount").val(num)
                zongjia.text(price * num)
                $.change(username, id, num)
            })
            $(".text-amount").each(function() {
                $(this).change(function() {
                    if ($(this).val() <= 1) {
                        $(this).val(1)
                    }
                    let wrap = $(this).parents(".list")
                    let price = wrap.find(".aprice").text()
                    let zongjia = wrap.find(".zongjia")
                    let id = $(this).parents(".list").attr("data-id")
                    zongjia.text(price * $(this).val())
                    $.change(username, id, $(this).val())
                });
            });
            // 删除
            $(".delete").click(function() {
                    let wrap = $(this).parents(".list")
                    let id = wrap.attr("data-id")
                    console.log(id);
                    $.ajax({
                        type: 'get',
                        url: 'http://localhost:3000/proList/' + username,
                        success: data => {
                            if (data.data) {
                                let Data = JSON.parse(data.data)
                                delete Data[id]
                                data.data = JSON.stringify(Data)
                                $.ajax({
                                    type: "put",
                                    url: 'http://localhost:3000/proList/' + username,
                                    data: data,
                                    success: function(data) {
                                        console.log("success");
                                    }
                                });
                            }
                        }
                    })
                })
                // 更改数据函数封装
            $.change = function(username, id, num) {
                $.ajax({
                    type: 'get',
                    url: 'http://localhost:3000/proList/' + username,
                    success: data => {
                        if (data.data) {
                            let Data = JSON.parse(data.data)
                            Data[id] = num
                            data.data = JSON.stringify(Data)
                            $.ajax({
                                type: "put",
                                url: 'http://localhost:3000/proList/' + username,
                                data: data,
                                success: function(data) {
                                    console.log("success");
                                }
                            });
                        }
                    }
                })
            }
        })
    } else {
        let html = `<a href="login.html" class="login">请登录</a>
        <a href="regiseter.html" class="zhuce" target="_blank">注册有礼</a>`
        $("#zhuangtai").html(html)
        $("#qingdenglu").show()
        $("#userNickname").text("")
        $("#cartnum").text(0)
    }
})