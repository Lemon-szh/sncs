$(function() {
    let id = location.search.split("=")[1]
    if ($.cookie('username')) {
        let username = $.cookie('username')
        $.get("../json/proList.json", function(data) {
            let html = `
            <div class="name">${data[id].title}</div>
            <div class="price">
                <span>价格:</span>
                <p>￥<em>${data[id].price}</em></p>
            </div>
            
            `
            $(".xiangq").html(html)
            let imghtml = `
                <div class="small">
                <img class="smallpic" src="../${data[id].imgsrc}">
                <div class="smallmove"></div>
                </div>
                <ul class="tab">
                    <li>
                        <img alt="" src="../${data[id].imgsrc}">
                    </li>
                    <!--<li>
                        <img alt="" src="../${data[id].imgsrc1}">
                    </li>
                    <li>
                        <img alt="" src="../${data[id].imgsrc2}">
                    </li>-->
                </ul>
                <div class="big">
                    <img class="bigpic" src="../${data[id].imgsrc}">
                </div>
                `
            $(".scale").html(imghtml)
        }).then(function() {
            magnify();

        })

        function magnify() {
            var small = $('.small');
            var smallpic = $('.small .smallpic');
            var smallmove = $('.small .smallmove');
            var big = $('.scale .big');
            var bigpic = $('.big .bigpic');
            var tab = $('.tab li:not(.btn)');
            small.on('mouseover', function() {
                smallmove.removeClass('hide').addClass('show');
                big.removeClass('hide').addClass('show');
                smallmove.css({
                    "width": small.width() * big.width() / bigpic.width(),
                    "height": small.height() * big.height() / bigpic.height()
                });
            });
            small.on('mousemove', function(ev) {
                ev = ev || event;
                var sLeft = ev.pageX - small.offset().left - smallmove.width() / 2 - 1;
                var sTop = ev.pageY - small.offset().top - smallmove.height() / 2 - 1;
                if (sLeft <= 0) {
                    sLeft = 0;
                } else if (sLeft >= small.width() - 2 - smallmove.width()) {
                    sLeft = small.width() - 2 - smallmove.width();
                }
                if (sTop <= 0) {
                    sTop = 0;
                } else if (sTop >= small.height() - 2 - smallmove.height()) {
                    sTop = small.height() - 2 - smallmove.height();
                }
                smallmove.css({
                    left: sLeft,
                    top: sTop
                });
                var ratio = bigpic.width() / big.width();
                bigpic.css({
                    left: (-1) * sLeft * ratio,
                    top: (-1) * sTop * ratio
                });
            }).on('mouseout', function() {
                smallmove.addClass('hide').removeClass('show');
                big.addClass('hide').removeClass('show');
            });
            tab.on('mouseenter', function() {
                var newsrc = $(this).children().attr('src');
                small.children('img').attr('src', newsrc);
                big.children('img').attr('src', newsrc);
            })
        }

        $("#leftbtn").on("click", function() {
            let num = $("#ainput").val()
            num--
            if (num <= 1) {
                num = 1
            }
            $("#ainput").val(num)
        })
        $("#rightbtn").on("click", function() {
            let num = $("#ainput").val()
            num++
            $("#ainput").val(num)
        })
        $("#ainput").change(function() {
            let num = $(this).val()
            if (num <= 1) {
                $(this).val(1)
            }
        });
        //添加购物车
        $("#jiaru").click(function() {
            let num = parseInt($("#ainput").val())
            if (num >= 1) {
                $.ajax({
                    type: 'get',
                    url: 'http://localhost:3000/proList/' + username,
                    success: data => {
                        console.log(data);
                        if (data.data) {
                            var Data = JSON.parse(data.data)
                            if (Data[id]) {
                                Data[id] += num
                            } else {
                                Data[id] = num
                            }
                        } else {
                            var Data = {}
                            Data[id] = num
                        }
                        data.data = JSON.stringify(Data)
                        $.ajax({
                            type: "put",
                            url: 'http://localhost:3000/proList/' + username,
                            data: data,
                            success: function(data) {
                                console.log("success");
                                location.href = "cart.html"
                            }
                        });
                    }
                })
            }
        })
    } else {
        location.href = "login.html"
    }
})