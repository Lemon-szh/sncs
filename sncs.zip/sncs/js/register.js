$(function() {
    let flag = false
    let flag1 = false
    let flag2 = false
    $("#username").change(function() {
        let $username = $(this).val()
        $.ajax({
            type: "get",
            url: "http://localhost:3000/user/" + $username,
            success: function(data) {
                $(".gsbd1").text("该用户名已存在").css("color", "red").show()
                flag = false
            },
            error: function() {
                $(".gsbd1").text("该用户名可以使用").css("color", "green").show()
                flag = true
            }
        });
    })
    $("#email").change(function() {
        if ($("#email").val() == "") {
            $(".gsbd2").text("邮箱不能为空").css("color", "red").show()
            flag1 = false
            return false;
        }
        var email = $("#email").val();
        if (!email.match(/^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/)) {
            $(".gsbd2").text("格式不正确！请重新输入").css("color", "red").show()
            flag1 = false
        } else {
            $(".gsbd2").text("格式正确").css("color", "green").show()
            flag1 = true
        };
    });
    $("#password").change(function() {
        var password = $("#password").val();
        if (!password.match(/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,12}$/)) {
            $(".gsbd3").text("格式不正确！请重新输入").css("color", "red").show()
            flag2 = false
        } else {
            $(".gsbd3").text("格式正确").css("color", "green").show()
            flag2 = true
        };
    });
    //用户名验证，邮箱验证，注册
    $(".zhuce").click(function() {
        console.log(flag && flag1 && flag2);
        if (flag && flag1 && flag2) {
            let $username = $("#username").val()
            let $email = $("#email").val()
            let $password = $("#password").val()
            var data = { $username: [{ "password": $password, "email": $email }] }
            $.ajax({
                type: "post",
                url: "http://localhost:3000/user",
                data: { "id": $username, "password": $password, "email": $email },
            });
            $.ajax({
                type: "post",
                url: "http://localhost:3000/proList",
                data: { "id": $username, "data": "" },
                success: function(data) {
                    location.href = "login.html"
                }
            });
        }
    })
})