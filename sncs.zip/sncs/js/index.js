$(function() {
    // 登录状态的判断和改变
    if ($.cookie('username')) {
        let username = $.cookie('username')
        let html = `<a href="javascript:;" class="login">${username}</a>
        <a href="javascript:;" class="regiset" id="tuichu">退出</a>`
        $("#zhuangtai").html(html)
        $("#qingdenglu").hide()
        $("#userNickname").text(username)
        $("#tuichu").click(function() {
            $.cookie('username', null)
        })
        $("#rightCart").click(function() {
            location.href = "html/cart.html"
        })
        $.ajax({
            type: 'get',
            url: 'http://localhost:3000/proList/' + username,
            success: data => {
                let num = 0
                if (data.data) {
                    let Data = JSON.parse(data.data)
                    for (let key in Data) {
                        num++
                    }
                }
                $("#cartnum").text(num)
                $("#topCartNum").text(num)
            }
        })
        $.ajax({
            type: 'get',
            url: 'http://localhost:3000/proList/' + username,
            success: data => {
                let str = ''
                if (data.data) {
                    let Data = JSON.parse(data.data)
                    for (let key in Data) {
                        $.get("json/proList.json", function(data) {
                            let proData = data
                            console.log(proData[key]);
                            str += `
                            <li>
                                <a href="html/cart.html"><img src=${proData[key].imgsrc} alt=""></a>
                                <span>${proData[key].title}</span>
                            </li>
                            `
                            $(".cart-box").html(str)
                        })
                    }
                }
            }
        }).then(function() {
            $(".loading-content").hide()
        })
    } else {
        let html = `<a href="html/login.html" class="login">请登录</a>
        <a href="html/regiseter.html" class="regiset" target="_blank">注册有礼</a>`
        $("#zhuangtai").html(html)
        $("#qingdenglu").show()
        $("#userNickname").text("")
        $("#cartnum").text(0)
        $("#topCartNum").text(0)
        $(".loading-content").show()
    }
    //划过变色
    $(".nav .hNav").has(".head-loading").hover(function() {
        $(this).find("a").children("em").toggleClass("glyphicon-menu-up")
        $(this).toggleClass("navLeftHover").children(".head-loading").stop(true, true).slideToggle(100).end().find(".masking").toggle()
    });
    // 搜索
    $("#searchKeywords").on("focus", function() {
        $("#rec_results").show()
    })
    $("#searchKeywords").on("blur", function() {
        $("#rec_results").hide()
        $("#ac_results").hide()
    })
    $("#searchKeywords").on("input", function() {
        $("#rec_results").hide()
        let search = $(this).val()
        let html = ""
        let url = `https://suggest.taobao.com/sug?code=utf-8&q=${search}&_ksTS=1577416162748_969&callback=?`
        $.getJSON(url, function(data) {
            if (data.result) {
                for (let i = 0; i < data.result.length; i++) {
                    html += `<li>${data.result[i][0]}</li>`
                }
            }
            $("#oUl").html(html)
            $("#ac_results").show()
        });
    });
    // 二级菜单
    (function() {
        $(".second-list li").hover(function() {
            let index = $(this).index();
            $(".third-item").eq(index).show().siblings().hide();
            $(this).css({ "background": "red", "color": "#fff" }).find("em").css({ "color": "#fff" });
            $(this).find("a").css({ "color": "#fff" })
            $(this).siblings().css({ "background": "#fff", "color": "#fff" }).find("em").css({ "color": "#333" })
            $(this).siblings().find("a").css({ "color": "#333" })
        }, function() {
            $(this).css({ "background": "#fff", "color": "#fff" }).find("em").css({ "color": "#333" })
            $(this).find("a").css({ "color": "#333" })
        })
        $(".third-item").on("mouseenter", function() {
            let index = $(this).index();
            $(".second-list li").eq(index).css({ "background": "red", "color": "#fff" }).find("em").css({ "color": "#fff" })
            $(".second-list li").eq(index).find("a").css({ "color": "#fff" })
        })
        $(".third-item").on("mouseleave", function() {
            let index = $(this).index();
            $(".second-list li").eq(index).css({ "background": "#fff", "color": "#fff" }).find("em").css({ "color": "#333" })
            $(".second-list li").eq(index).find("a").css({ "color": "#333" })
            $(this).hide()
        })
        $(".c-nav").on("mouseleave", function() {
            $(".third-item").hide()
        })
    })();
    // 三级菜单的数据
    (function() {
        $.get("json/nav.json", function(data) {
            let html = ""
            for (let id in data) {
                let dlstr = "";
                for (let title in data[id]) {
                    // console.log(title);
                    // console.log(data[id][title]);
                    let str = "";
                    for (let i = 0; i < data[id][title].length; i++) {
                        str += `<a href="javascript:;">${data[id][title][i]}</a> `
                    }
                    dlstr += `
                    <dl class="dlborder">
                    <dt><a href="javascript:;">${title}</a></dt >
                    <dd>
                        ${str}
                    </dd>
                    </dl> 
                    <em class="split-line2"></em> 
                    <em class="split-line2 split-line3"></em>`
                }
                html += `<div class="third-item">${dlstr}</div>`
            }
            $(".third-list").html(html)
        });
    })();


    // 轮播
    ;
    (function() {
        let bannerTimer = null
        let count = 0;
        $(".banner-wrapper").hover(function() {
            $(".banner-wrapper .point").show()
            clearInterval(bannerTimer)
        }, function() {
            $(".banner-wrapper .point").hide()
            bannerTimer = setInterval(function() {
                count++;
                if (count == $(".banner .banner-item").length) {
                    count = 0;
                }
                move(count);
            }, 3000);
        });
        $(".banner .banner-item").eq(count).css({ "opacity": "1" }).show()
        bannerTimer = setInterval(function() {
            count++;
            if (count == $(".banner .banner-item").length) {
                count = 0;
            }
            move(count);
        }, 3000);
        $(".banner-wrapper .left-point").on("click", function() {
            count--;
            if (count < 0) {
                count = $(".banner .banner-item").length - 1
            }
            move(count);
        })
        $(".banner-wrapper .right-point").on("click", function() {
            count++;
            if (count == $(".banner .banner-item").length) {
                count = 0
            }
            move(count);
        })
        $(".banner-nav a").on("mouseover", function() {
            let index = $(this).index()
            $(this).addClass("current").siblings().removeClass("current");
            move(index);
        })

        function move(count) {
            $(".banner .banner-item").eq(count).siblings().stop().animate({ "opacity": 0 }, 300, ).end().show().stop().animate({ "opacity": "1" }, 300)
                //角标的变化
            $(".banner-nav a").eq(count).addClass("current").siblings().removeClass("current");
        }
    })();
    // 优惠合集轮播
    (function() {
        $.get("json/proData.json", function(data) {
            let html = ""
            if (data["优惠合集"]) {
                for (let key in data["优惠合集"]) {
                    let str = ""
                    for (let i = 0; i < data["优惠合集"][key].length; i++) {
                        str += `
                        <li>
                                    <a href="html/detail.html?id=${data["优惠合集"][key][i].id}">
                                        <img src=${data["优惠合集"][key][i].imgsrc} alt="">
                                        <p class="name">${data["优惠合集"][key][i].title}</p>
                                        <p class="price">￥${data["优惠合集"][key][i].price}<em class="glyphicon glyphicon-shopping-cart"></em></p>
                                    </a>
                                </li>
                        `
                    }
                    html += `
                    <div class="kuai1">
                            <ul>
                                ${str}
                            </ul>
                        </div>
                    `
                }
                $(".kuai").html(html)
            }
        }, );
        let ofenbuyTimer = null
        let count = 0;
        $(".ofenbuy").hover(function() {
            $(".ofenbuy .point").show()
            clearInterval(ofenbuyTimer)
        }, function() {
            $(".ofenbuy .point").hide()
            ofenbuyTimer = setInterval(function() {
                count++;
                if (count == $(".ofenbuy .kuai .kuai1").length) {
                    count = 0;
                }
                move(count);
            }, 3000);
        });
        // $(".ofenbuy .kuai .kuai1").eq(count).css({ "opacity": "1" }).show()
        ofenbuyTimer = setInterval(function() {
            count++;
            if (count == $(".ofenbuy .kuai .kuai1").length) {
                count = 0;
            }
            move(count);
        }, 3000);
        $(".ofenbuy .pointleft").on("click", function() {
            count--;
            if (count < 0) {
                count = $(".ofenbuy .kuai .kuai1").length - 1
            }
            move(count);
        })
        $(".ofenbuy .pointright").on("click", function() {
            count++;
            if (count == $(".ofenbuy .kuai .kuai1").length) {
                count = 0
            }
            move(count);
        })

        function move(count) {
            $(".ofenbuy .kuai .kuai1").eq(count).siblings().stop().animate({ "opacity": 0 }, 300, ).hide().end().show().stop().animate({ "opacity": "1" }, 300)
        }
    })();
    (function() {
        $(".huibuy .sagetu li")
        let huiTimer = null
        let count = 0;
        $(".huibuy").hover(function() {
            $(".huibuy .point").show()
            clearInterval(huiTimer)
        }, function() {
            $(".huibuy .point").hide()
            huiTimer = setInterval(function() {
                count++;
                if (count == $(".huibuy .sagetu li").length) {
                    count = 0;
                }
                move(count);
            }, 3000);
        });
        $(".huibuy .sagetu li").eq(count).css({ "opacity": "1" }).show()
        huiTimer = setInterval(function() {
            count++;
            if (count == $(".huibuy .sagetu li").length) {
                count = 0;
            }
            move(count);
        }, 3000);
        $(".huibuy .pointleft1").on("click", function() {
            count--;
            if (count < 0) {
                count = $(".huibuy .sagetu li").length - 1
            }
            move(count);
        })
        $(".huibuy .pointright1").on("click", function() {
            count++;
            if (count == $(".huibuy .sagetu li").length) {
                count = 0
            }
            move(count);
        })

        function move(count) {
            $(".huibuy .sagetu li").eq(count).siblings().stop().animate({ "opacity": 0 }, 300, ).end().show().stop().animate({ "opacity": "1" }, 300)
        }
    })();
    //优选好物
    (function() {
        $.get("json/proData.json", function(data) {
            let html = ""
            if (data["优选好物"]) {
                for (let key in data["优选好物"]) {
                    let str = ""
                    for (let i = 0; i < data["优选好物"][key].length; i++) {
                        str += `
                        <li>
                                    <a href="html/detail.html?id=${data["优选好物"][key][i].id}" class="zcc">
                                        <img src=${data["优选好物"][key][i].imgsrc} alt="">
                                        <p class="name">${data["优选好物"][key][i].title}</p>
                                        <p class="price">￥${data["优选好物"][key][i].price}<em class="glyphicon glyphicon-shopping-cart"></em></p>
                                    </a>
                                </li>
                        `
                    }
                    html += `
                    <div class="tabcontent1 clean">
                            <ul class="clean">
                                ${str}
                            </ul>
                        </div>
                    `
                }
                $(".tabcontent").html(html)
            }
        }, );
        $(".chosengooder .tabnav li").on("mouseenter", function() {
            let index = $(this).index()
            $(this).find(".line6").addClass("hover").end().siblings().find(".line6").removeClass("hover")
            $(".tabcontent .tabcontent1").eq(index).show().siblings().hide()
        });
    })();
    // 排行榜
    (function() {
        $.get("json/proData.json", function(data) {
            let html = ""
            if (data["排行榜"]) {
                for (let key in data["排行榜"]) {
                    let str = ""
                    for (let i = 0; i < data["排行榜"][key].length; i++) {
                        str += `
                    <li>
                                <a href="html/detail.html?id=${data["排行榜"][key][i].id}" class="zcc">
                                    <img src=${data["排行榜"][key][i].imgsrc} alt="">
                                    <p class="name">${data["排行榜"][key][i].title}</p>
                                    <p class="price">￥${data["排行榜"][key][i].price}<em class="glyphicon glyphicon-shopping-cart"></em></p>
                                </a>
                            </li>
                    `
                    }
                    html += `
                <div class="crankcount">
                <ul>
                    ${str}
                </ul>
            </div>
                `
                }
                $("#crankcount").html(html)
            }
        });
        $(".cranknav li").eq(0).addClass("li2").children().addClass("p2")
        $(".cranknav li").hover(function() {
            $(this).addClass("li1").siblings().removeClass("li1").children().removeClass("p1")
            $(this).children().addClass("p1")
        })
        $(".cranknav li").on("click", function() {
            $(this).addClass("li2").siblings().removeClass("li2").children().removeClass("p2")
            $(this).children().addClass("p2")
            let index = $(this).index()
            $(".crankcount").eq(index).show().siblings().hide()
        })
    })();
    // 中间部分
    (function() {
        let Data;
        $.get("json/proList.json", (data) => {
            Data = data
        }).then(function() {
            $.get("json/proData.json", function(data) {
                let html = ""
                for (let i = 0; i < data.producelist.length; i++) {
                    let str = ""
                    for (let j = 0; j < data.producelist[i].sp.length; j++) {
                        str += `
                        <li><a href="javascript:;">${data.producelist[i].sp[j]}</a></li>
                        `
                    };
                    let list = ""
                    for (let g = 0; g < data.producelist[i].list.length; g++) {
                        let id = data.producelist[i].list[g]
                        list += `
                            <li>
                                <a href="html/detail.html?id=${id}" class="zxp">
                                    <img src=${Data[id].imgsrc} alt="">
                                    <p class="name">${Data[id].title}</p>
                                    <p class="price">￥${Data[id].price}<em class="glyphicon glyphicon-shopping-cart"></em></p>
                                </a>
                            </li>
                            `
                    };
                    html += `
                <div class="commodityer clouti">
                <div class="commodity">
                    <div class="ctitle ">
                        <p class="icon"></p>
                        <p class="titler">${data.producelist[i].title}</p>
                        <div class="ewm">
                            <span class="iconfont icon-ico"></span>
                            <p class="dewm"><img src=${data.producelist[i].imgsrc1}></p>
                        </div>
                    </div>
                    <div class="col11">
                        <a href="javascript:;"><img src=${data.producelist[i].imgsrc2} alt=""></a>
                        <div class="sp">
                            <ul>
                                ${str}
                            </ul>
                        </div>
                    </div>
                    <div class="col22">
                        <ul>
                            ${list}
                        </ul>
                    </div>
                </div>
            </div>
                `
                }
                $("#prolist").html(html)
            }, );
        })
    })();
    // 猜你喜欢
    (function() {
        $.get("json/proList.json", function(data) {
            let html = ""
            for (let key in data) {
                html += `
                        <li>
                            <a href="html/detail.html?id=${data[key].id}" class="zxp1">
                                <img src=${data[key].imgsrc} alt="">
                                <p class="name">${data[key].title}</p>
                                <p class="price">￥${data[key].price}<em class="glyphicon glyphicon-shopping-cart" data-id="${data[key].id}"></em></p>
                            </a>
                        </li>
                        `
            }
            $("#rec").html(html)
        }, );
    })();
    // 右边栏
    $(".snsidebar .snicon").not(".snic2").each(function() {
        $(this).hover(function() {
            $(this).css({ "background-color": "#FFAA01" }).siblings().css({ "background-color": "#FFAA01", "color": "#333" })
        }, function() {
            $(this).css({ "background-color": "#383838" }).siblings().css({ "background-color": "#383838", "color": "#FFAA01" })
        })
    });
    $(".snsidebar .carter").each(function() {
        $(this).hover(function() {
            $(this).css({ "background-color": "#FFAA01" })
        }, function() {
            $(this).css({ "background-color": "#383838" })
        })
    });
    $(".snsidebar .sntop .snchild").add($(".snsidebar .snmiddle .snchild")).each(function() {
        $(this).hover(() => {
            $(this).find(".snicon").siblings().show().stop().animate({
                "left": "-47px"
            }, 500)
        }, function() {
            $(this).find(".snicon").siblings().stop().animate({
                "left": "0"
            }, 500, () => {
                $(this).find(".snicon").siblings().hide()
            });
        })
    });
    $(".snsidebar .snbottom .snchild").each(function() {
        $(this).hover(() => {
            $(this).find(".snicon").siblings().show().stop().animate({
                "left": "-73px"
            }, 500)
        }, function() {
            $(this).find(".snicon").siblings().stop().animate({
                "left": "0"
            }, 500, () => {
                $(this).find(".snicon").siblings().hide()
            });
        })
    });
    $(".snsidebar .snbottom .snbottomewm").each(function() {
        $(this).hover(() => {
            $("#snbottomEwm").show().stop().animate({
                "left": "-160px"
            }, 500)
        }, function() {
            $("#snbottomEwm").stop().animate({
                "left": "0"
            }, 500, () => {
                $("#snbottomEwm").hide()
            });
        })
    });
    // 楼梯
    let flag = true;
    $(window).scroll(function() {
        if (flag) {
            let st = $(this).scrollTop();
            if (st > 288) {
                $("#wrap_floatBar").fadeIn();
            } else {
                $("#wrap_floatBar").fadeOut();
            }
            $(".clouti").each(function() {
                if (st >= $(this).offset().top - $(window).height() / 2) {
                    let index = $(this).index((".clouti"));
                    $("#wrap_floatBar .list li").eq(index).addClass("on").siblings().removeClass("on");
                }
            })
        }
    });
    $('#wrap_floatBar .list li').click(function() {
        flag = false;
        let index = $(this).index();
        $("#wrap_floatBar .list li").eq(index).addClass("on").siblings().removeClass("on");
        $('body,html').stop().animate({
            "scrollTop": $(".clouti").eq(index).offset().top
        }, 800, function() {
            flag = true;
        });
    });
    $(".float-title").hover(function() {
        $(this).find("p").show()
    }, function() {
        $(this).find("p").hide()
    });
    $("#wrap_floatBar .backTop").click(function() {
        $(window).scrollTop(0);
    });
});